http_path = "../"
css_dir = "css"
sass_dir = "scss"
images_dir = "imagens"
javascripts_dir = "js"
fonts_dir = css_dir + "/fonts"

output_style = :compact
#output_style = :compressed